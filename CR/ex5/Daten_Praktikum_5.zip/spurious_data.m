%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Computerarithmetik und Rechenverfahren
% OTH Regensburg, SoSe 2016
% Martin Wei�
%
% spurious correlations
% suicides by hanging <-> spending on space research
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
data = [
1999	5427	18079
2000	5688	18594
2001	6198	19753
2002	6462	20734
2003	6635	20831
2004	7336	23029
2005	7248	23597
2006	7491	23584
2007	8161	25525
2008	8578	27731
2009	9000	29449
];
