#include "makros.h"


int FUNC(func0)
   ORG 2048;
   INSTRUCTION("function0",4);
ENDFUNC;

int FUNC(func1)
   ORG 4096;
   INSTRUCTION("function1",6);
ENDFUNC;

int FUNC(func2)
   ORG 512;
   INSTRUCTION("function2",8);
ENDFUNC;


int FUNC(func3)
   ORG 1024;
   INSTRUCTION("function3",8);
ENDFUNC;


STARTPROC
  int i=0;
  LOOPFOR(100)
   INSTRUCTION("sequence",10);
   IFC(i==0)
      func2();
   ENDIFC;
   IFC(i%4==3)
      func3();
   ENDIFC;
   i = (i + 1) % 10;
  ENDLOOPFOR;
ENDPROC;

