#include "makros.h"


int FUNC(func0)
   ORG 2048;
   INSTRUCTION("function2",10);
ENDFUNC;

int FUNC(func1)
   ORG 1024;
   INSTRUCTION("function1",30);
   func0();
ENDFUNC;


STARTPROC
  LOOPFOR(100)
   INSTRUCTION("sequence",10);
   func1();
  ENDLOOPFOR;
ENDPROC;

