// makros.h   Enth�lt Makros und globale Variablen zur Definition eines Benchmarkprogrammes, welches das Zugriffsverhalten 
//            auf Instruktionen in Form einer Adresssequenz erzeugt
//
// (c) 2011 Alexander Metzner, Hochschule Regensburg


#ifndef MAKROS__H
#define MAKROS__H

#include <stdio.h>
#include <iostream>
#include <map>
#include <stack>
#include <string>
#include <stdlib.h>
#include <time.h>


using namespace std;

int __init=1; map<string,int> __PC; stack<int> __orgStack; int __org=0;
stack<int> __ifResultStack; int __ifResult;
stack<int> __condStack; int __ifCond;
stack<bool> __realCondStack; bool __realCond;
FILE *__hdl;

bool __firstAddr = true;

void initD100()
{
   srand((unsigned)time( NULL ) );
}


int D100()
{
   return ((rand()%100)+1);
}


#define STARTPROC int main(int argc, char *argv[]){ __hdl = fopen(argv[1],"w"); initD100(); for(int __g=0;__g<2;__g++){
#define ENDPROC __init=0;} fclose(__hdl); return 1; }

#define LOOPFOR(lcnt) int __f=0;while(__init || (__f<lcnt)){
#define ENDLOOPFOR __f++;if(__init) break;}

#define LOOPWHILE(cond) while(__init || (cond)){
#define ENDLOOPWHILE if(__init) break;}

#define ORG __org =

#define FUNC(FName) FName(){__orgStack.push(__org);
#define RETURN __org=__orgStack.top();__orgStack.pop(); return 
#define ENDFUNC __org=__orgStack.top();__orgStack.pop();}

#define GOTO if(__init) ; else goto

#define IFP(cond) __condStack.push(__ifCond); __ifResultStack.push(__ifResult);__ifResult = D100(); __ifCond=cond; if (__init || __ifResult<=__ifCond) { 
#define ENDIFP __ifResult = __ifResultStack.top(); __ifResultStack.pop(); __ifCond = __condStack.top(); __condStack.pop();}
#define ELSEP } if (__init || !(__ifResult<=__ifCond)) {

#define IFC(cond) __realCondStack.push(__realCond); __realCond=cond; if (__init || (__realCond)) { 
#define ENDIFC __realCond = __realCondStack.top(); __realCondStack.pop();}
#define ELSEC } if (__init || !(__realCond)) {

#define INSTRUCTION(IName,count) if (__init){__PC[string(IName)] = __org; __org +=count;}else{int __addr=__PC[string(IName)]; for(int __a=0; __a<count; __a++) if (__firstAddr) {fprintf(__hdl,"%d",__addr+__a);__firstAddr=false;}else fprintf(__hdl,"\n%d",__addr+__a);}

#endif

