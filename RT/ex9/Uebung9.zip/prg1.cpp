#include "makros.h"


int FUNC(func1)
   ORG 1024;
   INSTRUCTION("function1",30);
ENDFUNC;


STARTPROC
  LOOPFOR(100)
   INSTRUCTION("sequence",10);
   func1();
  ENDLOOPFOR;
ENDPROC;

