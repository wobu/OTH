function initBMICalculator() {
    alert("Let's start coding...");
}